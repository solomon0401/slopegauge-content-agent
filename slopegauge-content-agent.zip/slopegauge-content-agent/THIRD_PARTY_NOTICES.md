# Third-party components and assets

| Component | Source | License | Included notice |
|---|---|---|---|
| humanizer | https://github.com/blader/humanizer | MIT, Copyright (c) 2025 Siqi Chen | skills/humanizer/LICENSE |
| last30days | https://github.com/mvanhorn/last30days-skill | MIT, Copyright (c) 2026 Matt Van Horn | skills/last30days/LICENSE |
| bird-search, vendored by last30days | See the bundled package.json and LICENSE | MIT | skills/last30days/scripts/lib/vendor/bird-search/LICENSE |

These are snapshots of the owner's installed skills, not claims of the latest upstream release or complete development repositories. `provenance.json` records SHA-256 hashes of copied source files. The installed last30days snapshot identifies itself as v3.31.0. Upstream commit IDs were not available in the installed copies; none are invented.

The installed last30days package lacked its root LICENSE. The upstream [MIT notice](https://raw.githubusercontent.com/mvanhorn/last30days-skill/main/LICENSE) was verified on 2026-11-07 and restored. The upstream engine and Humanizer prompt have not been rewritten. Cache files, repository history and upstream GitHub automation were excluded from this runtime package.

Five custom skills were adapted only for portable dependency/asset resolution. They and the packaging helpers are covered by the root rights notice, not the dependencies' MIT licenses.

Brand materials in `skills/slopegauge-image-producer/assets/social-kit/` are the user-supplied SlopeGauge originals. `assets/style/` contains existing project artwork supplied as visual references. Their inclusion supports authorized SlopeGauge work; it is not a declaration that they are public-domain or openly licensed. No new external stock photo was downloaded for this release.

No credentials, account configuration, paid service access, model weights or host-system imagegen implementation are included. Optional service setup remains the recipient's responsibility.
