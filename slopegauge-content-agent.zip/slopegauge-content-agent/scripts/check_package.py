#!/usr/bin/env python3
"""Verify release source files against the bundled SHA-256 inventory."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {'.git', '.agents', '.codex', '.planning', 'work', 'outputs', '__pycache__', '.venv', 'node_modules'}


def main():
    expected = json.loads((ROOT / 'SHA256SUMS.json').read_text(encoding='utf-8'))
    actual = {}
    for path in ROOT.rglob('*'):
        rel = path.relative_to(ROOT)
        if any(part in IGNORED for part in rel.parts) or path.name == '.DS_Store':
            continue
        if path.is_symlink():
            raise ValueError(f'Unexpected symlink: {rel}')
        if path.is_file() and rel.as_posix() != 'SHA256SUMS.json':
            actual[rel.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    issues = [name for name in sorted(set(expected) | set(actual)) if expected.get(name) != actual.get(name)]
    if issues:
        print('Missing, added or changed files:\n' + '\n'.join(issues), file=sys.stderr)
        return 1
    print(f'PASS: {len(actual)} release files match the inventory.')
    print('This checks integrity, not research coverage, credentials or image-generation availability.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
