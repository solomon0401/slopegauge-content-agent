#!/usr/bin/env python3
"""Copy bundled skills to a project directory without replacing existing skills."""
import argparse
import hashlib
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]


def inventory(folder):
    result = {}
    for path in folder.rglob('*'):
        if path.is_symlink():
            raise ValueError(f'Symlink requires manual review: {path}')
        if path.is_file() and '__pycache__' not in path.parts and path.name != '.DS_Store':
            result[path.relative_to(folder).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dest', type=Path, default=ROOT / '.agents' / 'skills',
                        help='Destination skills directory; default is project .agents/skills')
    parser.add_argument('--check', action='store_true', help='Preview only; do not write')
    args = parser.parse_args()
    raw_dest = args.dest.expanduser().absolute()
    if any(p.is_symlink() for p in [raw_dest, *raw_dest.parents]):
        raise ValueError('Destination contains a symlink; choose a regular project folder')
    dest = raw_dest.resolve()
    source = ROOT / 'skills'
    if dest == source or source in dest.parents or dest in source.parents:
        raise ValueError('Destination must not overlap bundled source skills')
    if dest.exists() and not dest.is_dir():
        raise ValueError('Destination is not a directory')
    missing, conflicts = [], []
    for skill in sorted(source.iterdir()):
        if not skill.is_dir() or not (skill / 'SKILL.md').is_file():
            raise ValueError(f'Invalid bundled skill: {skill.name}')
        expected = inventory(skill)
        target = dest / skill.name
        if target.is_symlink():
            conflicts.append(skill.name)
        elif target.exists():
            if not target.is_dir() or inventory(target) != expected:
                conflicts.append(skill.name)
            else:
                print(f'Unchanged: {skill.name}')
        else:
            missing.append((skill, target))
    if conflicts:
        raise ValueError('Nothing installed. Existing different skills: ' + ', '.join(conflicts))
    for skill, target in missing:
        print(f'{"Would install" if args.check else "Installing"}: {skill.name}')
    if not args.check:
        dest.mkdir(parents=True, exist_ok=True)
        for skill, target in missing:
            shutil.copytree(skill, target)
    print(f'{"Preview complete" if args.check else "Installation complete"}: {dest}')
    print('Runtime research requires Python 3.12+ and configured search sources; images require host tools.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
