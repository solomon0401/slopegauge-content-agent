# 制作与交付

## 每页提示词骨架

只传该页需要的素材；先按可用工具要求查看本地图像，再正确引用。不同工具的参数以当前工具说明为准，不自行发明尺寸或输出路径参数。

```text
Use case: ads-marketing (or compositing / text-localization for an edit)
Asset: SlopeGauge Instagram carousel, slide {N}/6, portrait 4:5.
Input roles: {style reference}; {background}; {official logo}; {optional genuine product insert}.
Visual system: navy #102746, restrained purple #7650D6, white Helvetica/Arial-like
bold left-aligned headlines, consistent margins, logo scale, divider and footer.
Match the supplied brand reference and accepted anchor slide; do not copy their old copy/data.
Story / composition: {approved visual direction and hierarchy}.
Text, verbatim: {all approved English text, footer and applicable illustration/sample labels}.
Preserve: exact wording, punctuation, numerals, logo geometry and spelling;
genuine screenshot contents, units, dates, data and labels.
Avoid: invented UI, current-weather claims from sample data, extra slogans,
fake reportage, unrelated product imagery, visual drift.
Output target: 1080×1350 RGB PNG. Keep all text comfortably within the safe area.
```

尺寸写入提示词不等于工具保证尺寸。检查真实输出，不虚报达到规格。若需格式/尺寸转换，使用当前环境允许的导出能力；没有可用合规路径时明确报告缺口。栅格编辑与合成遵循 imagegen 的工具约束，不擅自换 Python 改图或改用付费 API。已有用户授权的确定性排版/导出流程可按其范围使用。

背景已经合适时保留它，只做所需合成/编辑，不生成另一座山替代。模型可能改变截图或 Logo；提示词要求不等于已保真，必须与原件核对。出现变形、拼写或数据变化就修复，不把仿造界面交付为真实截图。若当前工具始终无法保留关键素材，说明具体问题，请用户选择可行的制作方式，不默默省略已批准信息。

## 检查顺序

1. 每页打开实际输出检查：标题/正文/标点与批准稿逐字一致；无额外文案或缺字；日期、单位、数字和大小写准确。OCR 若可用只能辅助，不能代替看图。
2. 对照原图检查 Logo 完整比例、截图文字与读数；示例/示意标签清楚，注释不掩盖事实。
3. 缩小到手机阅读尺寸查看：正文、CTA 可读；边缘不切字；背景不抢字；每页信息有推进。
4. 六页一起审阅：同一字体家族、色调、边距、Logo、紫线、注释与页码；摄影地貌和光线不无故跳变；不要求六页完全一样。
5. 文件检查：恰好六张最终 PNG，顺序 01–06，1080×1350，RGB。不能用文件名或扩展名推断尺寸/色彩模式。只读检查可用 Pillow 等现有能力。
6. 有问题只修对应页，并检查修复是否损伤其他元素。通过后停止迭代。

## 保存与最终发布包

采用用户 2026-11-06 最新规范，覆盖旧的语义图片名、带主题目录和默认 DOCX：

- 工作记录：`work/slopegauge-images/YYYY-MM-DD-topic/` 下保存 production.json（批准稿、批准依据、素材、结果路径、模式与检查结果）、asset-sources.json 和实际 prompts.txt。双语审核文案、研究和草稿也留 work/。
- 最终目录：`outputs/YYYY-MM-DD/`，只含 `01.png`、`02.png`、`03.png`、`04.png`、`05.png`、`06.png`、`caption.txt` 七个文件。
- 日期用客户端时区（当前 Asia/Hong_Kong），不用主机默认日期；文件夹只有日期，不加品牌、主题后缀。用户指定日期时依其要求。
- caption.txt 使用 UTF-8，只有批准的英文发布文案，自然分段，包含单一 CTA、hashtags 和必要署名。没有 headline/tag/caption 等字段名、Markdown 格式、中文翻译、编辑说明或研究脚注。不要机械拼接提案各栏目，不重复标题。
- 沟通稿仍按 headline、内容、caption、text、口号分栏；它与最终纯发布文案用途不同。
- 默认提供 `outputs/YYYY-MM-DD.zip`，内含同名日期目录及上述七个文件。排除 .DS_Store、__MACOSX、临时文件、提示词、研究、草稿。检查包内路径和文件内容与选定成品一致。
- 图片保存到项目，不只留在工具默认目录。同任务修订保留旧版在 work/ 后更新；不同任务的同日成果不能覆盖，使用独立批次父目录，其内仍保持纯日期文件夹，必要时确认批次。

不再因“和之前一样”默认制作 DOCX；只有用户额外明确要求才读取 documents Skill，并使用已有批准文案制作及渲染检查。生成素材授权所需署名必须进入批准 caption 或适用位置，不能因格式简化省略。

局部修改只更新相应图片或 caption 及必要记录；如果已有同任务 ZIP，同步重建以避免交付旧版。不要重新制作未变更图片。只开发 Skill 时不运行内容生产。

交付前做基本文件检查：恰好七个最终文件、精确文件名、1080×1350 RGB、TXT 可解码且与批准 caption 一致、ZIP 不含废稿。独立总审查仍仅由用户手动调用，不自动挂入本流程。

最终给出日期目录和 ZIP 链接；所用模式、完整提示词和来源记录可链接工作目录，不放入发布文件夹。任何未解决的文字、数据、授权或导出问题都要说明，不虚报可直接发布。不自动发布 Instagram。
